import React from "react";

import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";
import TextField from "@material-ui/core/TextField";

import FindInPageIcon from "@material-ui/icons/FindInPage";
import CloudUploadIcon from "@material-ui/icons/CloudUpload";
import SearchIcon from "@material-ui/icons/Search";

import Collapse from "@material-ui/core/Collapse";

import AppBar from "../components/Appbar";
import FileExplorer from "../HomeExplorer/FileExplorer";
import Copyright from "../components/Copyright";

const useStyles = makeStyles(theme => ({
  icon: {
    marginRight: theme.spacing(2)
  },
  heroContent: {
    backgroundImage: "url(" + window.location.origin + "/books.jpg" + ")",
    // backgroundColor: theme.palette.background.paper,
    backgroundSize: "cover",
    padding: theme.spacing(8, 0, 6)
  },
  heroButtons: {
    marginTop: theme.spacing(4)
  },
  cardGrid: {
    paddingTop: theme.spacing(8),
    paddingBottom: theme.spacing(8)
  },
  card: {
    height: "100%",
    display: "flex",
    flexDirection: "column"
  },
  cardMedia: {
    paddingTop: "56.25%" // 16:9
  },
  cardContent: {
    flexGrow: 1
  },
  footer: {
    backgroundColor: theme.palette.background.paper,
    padding: theme.spacing(6)
  },
  leftIcon: {
    marginRight: theme.spacing(1)
  },
  rightIcon: {
    marginLeft: theme.spacing(1)
  },
  '@font-face': {
    fontFamily: 'Bungee',
    src: ["URL("+ window.location.origin + '/fonts/Bungee-Regular.ttf' +")","format('truetype')"],
  }
}));

export default function Main(props) {
  const { isAuthenticated, userDetails, handleLogout } = props;
  const classes = useStyles();
  const [unhide, setUnhide] = React.useState(true);
  const [searchTerm, setSearch] = React.useState("");

  function handleChange(e) {
    e.preventDefault();
    setSearch(e.target.value);
  }

  return (
    <React.Fragment>
      <CssBaseline />
      <AppBar position="relative" isAuthenticated={isAuthenticated} handleLogout={handleLogout} userDetails={userDetails} />
      <main>
        {/* Hero unit */}
        <Collapse in={unhide && !searchTerm}>
          <div className={classes.heroContent}>
            
          <Grid container alignItems="center" spacing={3}>
            <Grid item xs={4}>
            <Container maxWidth="sm">
              <Typography
                component="h1"
                variant="h2"
                align="center"
                color="textPrimary"
                gutterBottom
                style={{
                  fontFamily: 'Bungee',
                }}
              >
                Knowledge Management Portal
              </Typography>
              <Typography
                variant="h5"
                align="center"
                color="textSecondary"
                paragraph
              >
                This site contains all the documents and knowledge base of L&T
                Defence. You can search for items using keywords in the
                following textbox. Also, you can add documents using the add
                button.
              </Typography>
            </Container>
            <Grid item xs={8}>
            </Grid>
            </Grid>
            </Grid>
          </div>
        </Collapse>
        <Container className={classes.cardGrid} maxWidth="md">
          {/* End hero unit */}
          <Grid container alignItems="center" spacing={3}>
            <Grid item xs={8}>
              <TextField
                id="q"
                label="Search..."
                className={classes.textField}
                fullWidth
                placeholder="Enter keywords..."
                margin="normal"
                value={searchTerm}
                onChange={e => handleChange(e)}
                onFocus={() => setUnhide(unhide => !unhide)}
                onBlur={() => setUnhide(unhide => !unhide)}
              />
            </Grid>
            <Grid item xs>
              <Button
                variant="contained"
                color="default"
                className={classes.button}
              >
                <SearchIcon className={classes.leftIcon} />
                Search
              </Button>
            </Grid>
            <Grid item xs>
              <Button
                variant="contained"
                color="default"
                className={classes.button}
              >
                Deeply
                <FindInPageIcon className={classes.rightIcon} />
              </Button>
            </Grid>
          </Grid>
        </Container>
      </main>
      <React.Fragment>
        <FileExplorer isAuthenticated={false} searchTerm={searchTerm} handleLogout={handleLogout} userDetails={userDetails} />
      </React.Fragment>
      {/* Footer */}
      <footer className={classes.footer}>
        <Copyright />
      </footer>
      {/* End footer */}
    </React.Fragment>
  );
}
