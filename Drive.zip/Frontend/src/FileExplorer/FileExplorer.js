import React from "react";

import CssBaseline from "@material-ui/core/CssBaseline";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";

import AppBar from "./AppBar.js";
import FolderList from "./FolderList.js";

const oscontents = [
  {
    id: 1,
    name: "Windows 10 OEM x86_64.iso",
    size: "4.6Gb",
    modified: "21 April 2019...",
    folder: false,
    link: "/windows_10_OEM_x86_64.iso"
  },
  {
    id: 2,
    name: "Ubuntu 20.04.iso",
    size: "1.6Gb",
    modified: "4 months ago...",
    folder: false,
    link: "/Ubuntu_20.04_x86_64.iso"
  },
  {
    id: 3,
    name: "HelpFile.docx",
    size: "22Mb",
    modified: "22nd July 2017",
    folder: false,
    link: "/helpfile.docx"
  }
];

const data = [
  {
    id: 4,
    name: "Operating System",
    size: "---",
    modified: "a few seconds ago...",
    folder: true,
    contents: oscontents,
    published: false
  },
  {
    id: 9,
    name: "Softwares",
    size: "---",
    modified: "few minutes ago...",
    folder: true,
    contents: oscontents,
    published: true
  },
  {
    id: 5,
    name: "Cupcake.pdf",
    size: "35Mb",
    modified: "a few seconds ago...",
    folder: false,
    link: "/cupcake.pdf"
  },
  {
    id: 6,
    name: "Donut.png",
    size: "45Mb",
    modified: "a month ago...",
    folder: false,
    link: "/donut.png"
  },
  {
    id: 7,
    name: "Eclair.docx",
    size: "8Mb",
    modified: "22nd July 2017",
    folder: false,
    link: "/eclair.docx"
  },
  {
    id: 8,
    name: "Yoghurt.xlsx",
    size: "1.59Mb",
    modified: "12 January 2015",
    folder: false,
    link: "/yoghurt.xlsx"
  }
];

const updateName = (id, name) => {
  // TODO: implement an API endpoint for this function
  const newData = data;
};

export default function FileExplorer(props) {
  const { folderData } = props;

  const getFolder = id => {
    // TODO: implement an API endpoint for this function
    folderData.forEach(item => {
      if (item.folder && item.id === id) return item;
      else if (item.folder) return getFolder(item.contents, id);
    });
    return null;
  };

  const handleDeleteItem = id => {
    // TODO: implement an API endpoint for this function
    const newData = folderData.filter(item => item.id !== id);
    // setFolderData(newData);
  };

  const handlePublishItemToHome = id => {
    // TODO: implement an API endpoint for this function
    const newData = folderData.filter(item => item.id !== id);
    // setFolderData(newData);
  };

  return (
    <React.Fragment>
      <CssBaseline />
      <AppBar getFolder={getFolder} />
      <FolderList
        folderData={folderData}
        getFolder={getFolder}
        handleDeleteItem={handleDeleteItem}
      />
    </React.Fragment>
  );
}
