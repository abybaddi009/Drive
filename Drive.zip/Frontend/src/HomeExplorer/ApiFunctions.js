import axios from 'axios';

const PUBLIC_HOME_FOLDER_URL = 'http://localhost:8000/api/public/home/?format=json';
const PUBLIC_FOLDER_DATA_URL = 'http://localhost:8000/api/public/home/';
const PUBLIC_SEARCH_FILE_URL = `http://localhost:8000/api/public/search?format=json&q=`;

// AUTH URLs
const HEADER = {headers: {
    Authorization: `JWT ${localStorage.getItem("token")}`
  }}

const AUTH_FOLDER_CREATE_URL = 'http://localhost:8000/api/folder/';
const AUTH_HOME_FOLDER_URL   = 'http://localhost:8000/api/root_folder/';
const AUTH_FILE_UPDATE_URL   = 'http://localhost:8000/api/file/upload/';

export const getHomeFolderData = () => {
    return axios.get(PUBLIC_HOME_FOLDER_URL);
}

export const getSearchResultData = (q) => {
    return axios.get(PUBLIC_SEARCH_FILE_URL + q);
}

export const getFolderData = (folder_id) => {
    return axios.get(PUBLIC_FOLDER_DATA_URL + folder_id);
}

// AUTH promises
export const getAuthFolderData = (folder_id) => {
    return axios.get(AUTH_FOLDER_CREATE_URL + folder_id, HEADER);
}

export const postAuthFolderData = (folder_details) => {
    return axios.post(AUTH_FOLDER_CREATE_URL, folder_details, HEADER);
}

export const getAuthHomeFolderData = () => {
    return axios.get(AUTH_HOME_FOLDER_URL, HEADER);
}

export const postAuthFileData = (file_data) => {
    return axios.post(AUTH_FILE_UPDATE_URL, file_data, HEADER);
}