import axios from 'axios';

const HOME_FOLDER_URL = 'http://localhost:8000/api/public/home/?format=json';
const SEARCH_FILE_URL = `http://localhost:8000/api/public/search?format=json&q=`;
const FOLDER_DATA_URL = 'http://localhost:8000/api/folder/';

export const getHomeFolderData = () => {
    return axios.get(HOME_FOLDER_URL);
}

export const getSearchResultData = (q) => {
    return axios.get(SEARCH_FILE_URL + q);
}

export const getFolderData = (folder_id) => {
    return axios.get(FOLDER_DATA_URL + folder_id);
}


