import React from "react";

import axios from "axios";
import CssBaseline from "@material-ui/core/CssBaseline";

import AppBar from "./AppBar";
import FolderList from "./FolderList";
import CreateFolderDialog from "./createFolderDialog";
import CreateFileDialog from "./createFileDialog";
import AlertDialog from "../components/alertDialog";

import { getHomeFolderData, getSearchResultData, getFolderData, getAuthFolderData, postAuthFolderData, getAuthHomeFolderData , postAuthFileData} from "./ApiFunctions";

export default function FileExplorer(props) {
  const { searchTerm, isAuthenticated } = props;
  const [folderData, setFolderData] = React.useState(null);
  const [breadcrumbdata, setBreadCrumbData] = React.useState([{ id: 0, name: "Home", callData: null },]);
  const [selectedFolder, setSelectedFolder] = React.useState(null);
  const [createFolderDialogState, setCreateFolderDialogState] = React.useState(false);
  const [createFileDialogState, setCreateFileDialogState] = React.useState(false);
  const [alertDialogState, setAlertDialogState] = React.useState(false);
  const [alertTitleDesc, setAlertTitleDesc] = React.useState({ title: "", desc: "" })
  const [rootFolder, setRootFolder] = React.useState(null);

  const loadHomeFolder = () => {
    const getFolderDataPromise = isAuthenticated ? getAuthHomeFolderData : getHomeFolderData;
    getFolderDataPromise().then(res => {
      const newRootFolder = {};
      newRootFolder.name = "Home";
      newRootFolder.callData = loadHomeFolder;
      if (!isAuthenticated) {
        setFolderData(res.data);
        newRootFolder.id = 0;
        setSelectedFolder(null);
      }
      else {
        setFolderData(res.data.contents);
        newRootFolder.id = res.data.id;
        setSelectedFolder(res.data.id);
      }
      setRootFolder(newRootFolder);
      if (breadcrumbdata.length < 2) {
        setBreadCrumbData([newRootFolder,]);
      }
    })
      .catch((err) => {
        console.log(err);
      });
  }

  const loadOtherFolder = (id) => {
    const getFolderDataPromise = isAuthenticated ? getAuthFolderData : getFolderData;
    getFolderDataPromise(id).then(res => {
      if (!isAuthenticated) {
        setFolderData(res.data.contents);
        setSelectedFolder(null);
      }
      else {
        setFolderData(res.data.contents);
        setSelectedFolder(res.data.id);
      }
    })
      .catch((err) => {
        console.log(err);
      });
  }

  React.useEffect(() => {
    loadHomeFolder();
  }, []);

  React.useEffect(() => {
    if (searchTerm) {
      const getFolderDataPromise = isAuthenticated ? getAuthHomeFolderData : getHomeFolderData;
      const searchPromise = searchTerm.length > 2 ? getSearchResultData : getFolderDataPromise;
      searchPromise(searchTerm).then(res => {
        if (!isAuthenticated) {
          setFolderData(res.data);
          setSelectedFolder(null);
        }
        else {
          setFolderData(res.data.contents);
          setSelectedFolder(res.data.id);
        }
      })
        .catch(err => {
          console.log(err);
        })
    }
  }, [searchTerm]);

  const handleCreateNewFolder = (name, description) => {
    setCreateFolderDialogState(false);
    if (!selectedFolder) {
      setAlertTitleDesc({ title: "Invalid Folder", desc: "The folder cannot be created here." })
      setAlertDialogState(true);
      return;
    }
    const folder_data = {
      parent_folder: selectedFolder,
      name: name,
      owner: props.userDetails.id,
      description: description
    }
    postAuthFolderData(folder_data)
      .then(res => {
        console.log("folder created: ", res);
        setAlertTitleDesc({ title: "Folder created!", desc: `The folder ${folder_data.name} has been created.` })
        setAlertDialogState(true);
        loadHomeFolder();
        return;
      })
      .catch(err => {
        console.log(err);
        setAlertTitleDesc({ title: "Error occured!", desc: "" + err.message + ": " + err.response.data.detail })
        setAlertDialogState(true);
        loadHomeFolder();
      });
  }

  const handleNavigateFolder = id => {
    let navFolder = folderData.filter(folder => folder.id == id);
    navFolder = navFolder[0];
    navFolder.callData = loadOtherFolder;
    const breads = breadcrumbdata;
    breads.push(navFolder);
    setBreadCrumbData(breads);
    loadOtherFolder(navFolder.id);
  }

  const handleNavigateBreadCrumbs = id => {
    const breads = breadcrumbdata;
    let bread = breads.pop();
    while (bread.id != id) {
      bread = breads.pop();
    }
    setBreadCrumbData([...breads, bread]);
    if (bread.callData)
      bread.callData(bread.id);
    else
      loadHomeFolder();
  }

  const handleFileUpload = (e, name, description, fileName) => {
    e.preventDefault();
    const data = new FormData();
    data.append('name', name);
    data.append('description', description);
    data.append('location', fileName);
    data.append('parent_folder', selectedFolder);

    console.log(data);
    postAuthFileData(data)
      .then(res => {
        console.log("file created: ", res);
        setAlertTitleDesc({ title: "File uploaded!", desc: `The file ${res.data.name} has been created.` })
        setAlertDialogState(true);
        loadHomeFolder();
      })
      .catch(err => {
        console.log(err);
        setAlertTitleDesc({ title: "Error occured!", desc: "" + err.message + ": " + err.response.data.detail })
        setAlertDialogState(true);
        loadHomeFolder();
      });
  }

  return (
    <React.Fragment>
      <CssBaseline />
      {isAuthenticated && (<AppBar
        isAuthenticated={isAuthenticated}
        userDetails={props.userDetails}
        handleLogout={props.handleLogout}
        handleFileUpload={handleFileUpload}
        setCreateFileDialogState={setCreateFileDialogState}
        setCreateFolderDialogState={setCreateFolderDialogState} />)}
      <FolderList
        isAuthenticated={isAuthenticated}
        searchTerm={searchTerm}
        folderData={folderData}
        breadcrumbdata={breadcrumbdata}
        handleNavigateFolder={handleNavigateFolder}
        handleNavigateBreadCrumbs={handleNavigateBreadCrumbs}
      />
      <CreateFolderDialog open={createFolderDialogState} handleClose={setCreateFolderDialogState} handleSubmit={handleCreateNewFolder} />
      <CreateFileDialog open={createFileDialogState} handleClose={setCreateFileDialogState} handleSubmit={handleFileUpload} />
      <AlertDialog open={alertDialogState} setOpen={setAlertDialogState} title={alertTitleDesc.title} description={alertTitleDesc.desc} />
    </React.Fragment>
  );
}
