import React from "react";

import CssBaseline from "@material-ui/core/CssBaseline";

import AppBar from "./AppBar";
import FolderList from "./FolderList";

import { getHomeFolderData, getSearchResultData, getFolderData } from "./ApiFunctions";


export default function FileExplorer(props) {
  const { searchTerm, isAuthenticated } = props;
  const [folderData, setFolderData] = React.useState(null);
  const [breadcrumbdata, setBreadCrumbData] = React.useState([{ name: 'Home', id: 0, callData: getHomeFolderData }]);
  const [selectedFolder, setSelectedFolder] = React.useState(null);

  React.useEffect(() => {
    getHomeFolderData().then(res => {
      console.log(res);
      setFolderData(res.data)
    })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  React.useEffect(() => {
    if (searchTerm) {
      const searchPromise = searchTerm.length > 2 ? getSearchResultData : getHomeFolderData;
      searchPromise(searchTerm).then(res => {
        console.log(res);
        setFolderData(res.data);
      })
        .catch(err => {
          console.log(err);
        })
    }
  }, [searchTerm]);

  const handleNavigateFolder = id => {
    let navFolder = folderData.filter(folder => folder.id == id);
    navFolder = navFolder[0];
    navFolder.callData = getFolderData;
    const breads = breadcrumbdata;
    breads.push(navFolder);
    setBreadCrumbData(breads);
    getFolderData(navFolder.id).then(res => {
      console.log(res);
      setFolderData(res.data.contents)
    })
      .catch((err) => {
        console.log(err);
      });
  }

  const handleNavigateBreadCrumbs = id => {
    const breads = breadcrumbdata;
    let bread = breads.pop();
    while (bread.id != id) {
      bread = breads.pop();
    }
    setBreadCrumbData([...breads, bread]);
    bread.callData(bread.id).then(res => {
      console.log(res);
      if (res.data.contents)
        setFolderData(res.data.contents)
      else
        setFolderData(res.data)
    })
      .catch(err => {
        console.log(err);
      });
  }

  return (
    <React.Fragment>
      <CssBaseline />
      {isAuthenticated && (<AppBar isAuthenticated={isAuthenticated} userDetails={props.userDetails} handleLogout={props.handleLogout} />)}
      <FolderList
        isAuthenticated={isAuthenticated}
        searchTerm={searchTerm}
        folderData={folderData}
        breadcrumbdata={breadcrumbdata}
        handleNavigateFolder={handleNavigateFolder}
        handleNavigateBreadCrumbs={handleNavigateBreadCrumbs}
      />
    </React.Fragment>
  );
}
