import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles(theme => ({
  button: {
    margin: theme.spacing(1),
  },
  input: {
    display: 'none',
  },
}));

export default function FormDialog(props) {
  const classes = useStyles();

  const { open, handleClose, handleSubmit } = props;
  const [name, setName] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [fileName, setFileName] = React.useState("");

  return (
    <div>
      <Dialog open={open} onClose={(e) => handleClose(false)} aria-labelledby="form-dialog-title">
        <DialogTitle id="form-dialog-title">Upload a new file</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            id="name"
            label="Name"
            onChange={(e) => setName(e.target.value)}
            fullWidth
          />
        </DialogContent>
        <DialogContent>
          <TextField
            margin="dense"
            id="description"
            label="Description"
            value={description}
            onChange={e => setDescription(e.target.value)}
            fullWidth
          />
        </DialogContent>
        <DialogContent>
          <input
            accept=".pdf"
            className={classes.input}
            style={{ display: 'none' }}
            id="raised-button-file"
            onChange={e => setFileName(e.target.files[0])}
            type="file"
          />
          <Typography variant="body1">
            {fileName.name}
          </Typography>
          <label htmlFor="raised-button-file">
            <Button variant="raised" component="span" className={classes.button}>
              Upload
            </Button>
          </label> 
        </DialogContent>
        <DialogActions>
          <Button onClick={(e) => handleClose(false)} color="primary">
            Cancel
          </Button>
          <Button onClick={(e) => handleSubmit(e, name, description, fileName)} color="primary">
            Create
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
