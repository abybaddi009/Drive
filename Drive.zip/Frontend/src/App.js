import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import Routes from "./Routes";

function App(props) {
  const [isAuthenticated, setUserHasAuthenticated] = React.useState(false);
  const [userDetails, setUserDetails] = React.useState(null);

  // TODO: Implement login with setUserDetails

  // TODO: Implement this
  const handleLogout = async event => {
    //await Auth.signOut();

    localStorage.removeItem("token");
    setUserHasAuthenticated(false);

    props.history.push("/login");
  }

  const childProps = {
    isAuthenticated: isAuthenticated,
    setUserHasAuthenticated: setUserHasAuthenticated,
    setUserDetails: setUserDetails,
    userDetails: userDetails,
    handleLogout: handleLogout
  };

  return (
    <Routes childProps={childProps} />
  );
}

export default withRouter(App);
