import React from "react";
import axios from "axios";
import { withRouter } from "react-router-dom";
import Routes from "./Routes";

function App(props) {
  const [token, setToken] = React.useState(localStorage.getItem("token"));
  const [isAuthenticated, setUserHasAuthenticated] = React.useState(token !== "" ? true : false);
  const [userDetails, setUserDetails] = React.useState({ id: null, name: null, firstname: null, lastname: null });

  React.useEffect(() => {
    let isSubscribed = true;
    if (token != "") {
      axios
        .get("http://localhost:8000/api/current_user/", {
          headers: {
            Authorization: `JWT ${token}`
          }
        })
        .then(res => {
          if (isSubscribed) {
            console.log("getuserdata: ", res.data);
            setUserDetails(res.data);
            setUserHasAuthenticated(true);
          }
        })
        .catch(err => {
          console.log(err);
          localStorage.setItem("token", "");
          setToken("");
          setUserHasAuthenticated(false);
          setUserDetails(null);
        });
      return () => isSubscribed = false
    }
  }, [token]);
  // TODO: Implement login with setUserDetails

  // TODO: Implement this
  const handleLogout = () => {
    //await Auth.signOut();
    localStorage.setItem("token", "");
    setUserHasAuthenticated(false);

    props.history.push("/login");
  }

  const childProps = {
    isAuthenticated: isAuthenticated,
    setUserHasAuthenticated: setUserHasAuthenticated,
    setUserDetails: setUserDetails,
    userDetails: userDetails,
    handleLogout: handleLogout,
    setToken: setToken,
  };

  return (
    <Routes childProps={childProps} />
  );
}

export default withRouter(App);
