import React from 'react';

import Typography from '@material-ui/core/Typography';

export default function Copyright() {
    return (
        <React.Fragment>
            <Typography variant="h6" align="center">
                Developed with{" "}
                <span role="img" aria-label="Love">
                    ❤️
          </span>{" "}
                by
        </Typography>
            <Typography
                variant="subtitle1"
                align="center"
                color="textSecondary"
                component="p"
            >
                L&T Defence IT - Hazira
        </Typography>
        </React.Fragment>
    )
}