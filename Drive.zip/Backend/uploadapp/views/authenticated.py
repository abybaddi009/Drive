from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.parsers import FileUploadParser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import generics

from uploadapp.models import FolderModel, FileModel
from uploadapp.serializers import FolderSerializer, FileSerializer, UserSerializer


@api_view(['GET'])
def current_user(request):
    """
    Determine the current user by their token, and return their data
    """
    serializer = UserSerializer(request.user)
    return Response(serializer.data)


class FileUploadView(APIView):
    parser_class = (FileUploadParser, )
    permission_classes = []

    def post(self, request, *args, **kwargs):

        file_serializer = FileSerializer(data=request.data)

        if file_serializer.is_valid():
            instance = file_serializer.save(owner=request.user)
            return Response(file_serializer.data, status.HTTP_201_CREATED)
        else:
            return Response(file_serializer.errors,
                            status.HTTP_400_BAD_REQUEST)


class FolderList(generics.ListCreateAPIView):
    queryset = FolderModel.objects.all()
    serializer_class = FolderSerializer
    permission_classes = []


class FolderDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = FolderModel.objects.all()
    serializer_class = FolderSerializer
    permission_classes = []
