from rest_framework import status
from rest_framework.parsers import FileUploadParser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import generics

from uploadapp.models import FolderModel, FileModel
from uploadapp.serializers import FolderSerializer, FileSerializer


class FileUploadView(APIView):
    parser_class = (FileUploadParser, )

    def post(self, request, *args, **kwargs):

        file_serializer = FileSerializer(data=request.data)

        if file_serializer.is_valid():
            instance = file_serializer.save(owner=request.user)
            return Response(file_serializer.data, status.HTTP_201_CREATED)
        else:
            return Response(file_serializer.errors,
                            status.HTTP_400_BAD_REQUEST)


class FolderList(generics.ListCreateAPIView):
    queryset = FolderModel.objects.all()
    serializer_class = FolderSerializer


class FolderDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = FolderModel.objects.all()
    serializer_class = FolderSerializer
