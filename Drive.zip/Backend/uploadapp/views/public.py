from django.db.models import Q

from rest_framework import generics

from uploadapp.models import FolderModel, FileModel
from uploadapp.serializers import FileSerializer, FolderMinSerializer


class HomeFolderView(generics.ListAPIView):
    queryset = FolderModel.objects.filter(published=True).order_by('name')
    serializer_class = FolderMinSerializer


class HomeFileSearchView(generics.ListAPIView):
    serializer_class = FileSerializer

    def get_queryset(self):
        q = self.request.GET.get('q', None)

        if q is not None:
            return FileModel.objects.filter(name__icontains=q,
                                            parent_folder__published=False)
        else:
            return FileModel.objects.filter(parent_folder__published=False)
