from django.db.models import Q
from django.http import Http404

from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView

from uploadapp.models import FolderModel, FileModel
from uploadapp.serializers import FileSerializer, FolderMinSerializer, FolderSerializer


class HomeFolderView(generics.ListAPIView):
    '''
    Lists all published folders.
    This endpoint returns a list of all
    published folders from the database. 
    '''
    queryset = FolderModel.objects.filter(published=True).order_by('name')
    serializer_class = FolderMinSerializer


class HomeFileSearchView(generics.ListAPIView):
    '''
    Searches for the given 'q' string in the file names of all the published folders
    '''
    serializer_class = FileSerializer

    def get_queryset(self):
        q = self.request.GET.get('q', None)

        if q is not None:
            return FileModel.objects.filter(name__icontains=q,
                                            parent_folder__published=False)
        else:
            return []


class PublishedFolderDetail(APIView):
    """
    Retrieve a Public Folder instance.
    This endpoint takes in an 'ID' as a GET parameter,
    checks whether the folder published or is a subfolder 
    of a published folder and returns the details.
    """
    def get_object(self, pk):
        try:
            instance = FolderModel.objects.get(pk=pk)
            if instance.published:
                return instance
            folder = instance
            while folder.parent_folder is not None:
                folder = folder.parent_folder
                if folder.published:
                    return instance
            raise Http404
        except FolderModel.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        folder = self.get_object(pk)
        serializer = FolderSerializer(folder)
        return Response(serializer.data)
