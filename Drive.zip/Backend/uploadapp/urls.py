from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns

from .views.authenticated import FileUploadView, FolderList, FolderDetail, current_user
from .views.public import HomeFolderView, HomeFileSearchView


urlpatterns = [
    # public views
    path('public/home/', HomeFolderView.as_view()),
    path('public/search', HomeFileSearchView.as_view()),
    # authenticated views
    path('current_user/', current_user),
    path('file/upload/', FileUploadView.as_view()),
    path('folder/', FolderList.as_view()),
    path('folder/<int:pk>/', FolderDetail.as_view())
]

urlpatterns = format_suffix_patterns(urlpatterns)
