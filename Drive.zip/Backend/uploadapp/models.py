import uuid
import os

from django.contrib.auth.models import User
from django.db import models
from django.conf import settings
from django.db.models.signals import post_save
from django.shortcuts import reverse

from .signals import create_folder, create_user


def file_save_path(instance, filename):
    # print(filename)
    return os.path.join(instance.parent_folder.location, filename)


class FolderModel(models.Model):
    name = models.CharField(max_length=128, blank=False, null=False)
    description = models.CharField(max_length=500, blank=True, null=True)
    uid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created = models.DateTimeField(auto_now_add=True, blank=False, null=False)
    updated = models.DateTimeField(auto_now=True, blank=False, null=False)
    owner = models.ForeignKey(settings.AUTH_USER_MODEL,
                              on_delete=models.CASCADE, related_name="folders")
    parent_folder = models.ForeignKey("self", on_delete=models.CASCADE,
                                      related_name="folders", blank=True,
                                      null=True)
    location = models.FilePathField(
        path=settings.FILE_PATH_FIELD_DIRECTORY, blank=True, null=True, editable=False)
    published = models.BooleanField(default=False)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('uploadapp:folderview', kwargs={'uid': self.uid})


class FileModel(models.Model):
    name = models.CharField(max_length=128, blank=False, null=False)
    document_name = models.CharField(max_length=128, blank=False, null=False)
    description = models.CharField(max_length=500, blank=True, null=True)
    uid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created = models.DateTimeField(auto_now_add=True, blank=False, null=False)
    updated = models.DateTimeField(auto_now=True, blank=False, null=False)
    location = models.FileField(
        upload_to=file_save_path, blank=False, null=False)
    parent_folder = models.ForeignKey(FolderModel, on_delete=models.CASCADE,
                                      related_name="files")
    owner = models.ForeignKey(settings.AUTH_USER_MODEL,
                              on_delete=models.CASCADE, related_name="files")

    def __str__(self):
        return f'File {self.id} - {self.name} in {self.parent_folder}'

    def get_absolute_url(self):
        return reverse('media', kwargs={'path': self.location})


post_save.connect(create_folder, sender=FolderModel)
post_save.connect(create_user, sender=User)
