from django.contrib.auth.models import User
from django.utils.timesince import timesince

from rest_framework import serializers

from .models import FileModel, FolderModel


class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name']


class FileSerializer(serializers.ModelSerializer):
    owner = UserSerializer(read_only=True)
    updated = serializers.SerializerMethodField()
    size = serializers.SerializerMethodField()

    class Meta:
        model = FileModel
        fields = ['id', 'name', 'location', 'description', 'parent_folder',
                  'owner', 'document_name', 'created', 'updated', 'size']

    def get_updated(self, object):
        return timesince(object.updated)

    def get_size(self, object):
        suffixes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']

        file_size = object.location.size
        i = 0
        while file_size >= 1024 and i < len(suffixes):
            file_size /= 1024
            i += 1

        human_friendly_size = f'{file_size} {suffixes[i]}'

        return human_friendly_size


class FolderMinSerializer(serializers.ModelSerializer):
    username = serializers.SerializerMethodField()
    folder = serializers.SerializerMethodField()
    updated = serializers.SerializerMethodField()

    class Meta:
        model = FolderModel
        fields = ['id', 'name', 'updated', 'folder', 'published', 'username']

    def get_username(self, object):
        username = User.objects.get(pk=object.owner.id)
        return username.username

    def get_folder(self, object):
        return True

    def get_updated(self, object):
        return timesince(object.updated)


class FolderSerializer(serializers.ModelSerializer):
    contents = serializers.SerializerMethodField()
    breadcrumb = serializers.SerializerMethodField()

    class Meta:
        model = FolderModel
        fields = ('id', 'parent_folder', 'name', 'owner',
                  'description', 'contents', 'breadcrumb', 'published')

    def get_contents(self, object):
        folder_serializer = FolderMinSerializer(
            FolderModel.objects.filter(parent_folder__id=object.id), many=True)
        file_serializer = FileSerializer(object.files.all(), many=True)
        return folder_serializer.data + file_serializer.data

    def get_breadcrumb(self, folder):
        breadcrumb = []
        while folder.parent_folder is not None:
            folder = folder.parent_folder
            breadcrumb.append(FolderMinSerializer(folder).data)
        breadcrumb.reverse()
        return breadcrumb
