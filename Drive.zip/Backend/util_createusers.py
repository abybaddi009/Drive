from django.contrib.auth.models import User

from uploadapp.models import FolderModel

def createUser(name, password, firstname, lastname):
    user = User.objects.create_user(name, password=password)
    user.first_name = firstname
    user.last_name  = lastname
    user.is_staff = True
    user.save()
    return user

def createFolder(folder_name, user):
    root_folder = FolderModel.objects.filter(name='root_' + user.username)[0]

    folder = FolderModel.objects.create(name=folder_name,
                owner=user,
                parent_folder=root_folder,
                published=True)
    return folder

def create_users():
    ## QC - 122784
    user   = createUser('122784', 'aby@12345', 'Munjal', 'Patel')
    folder = createFolder('Quality Control', user)
    folder = createFolder('Quality Assurance & Laboratory', user)
    folder = createFolder('TQM', user)
    folder = createFolder('NDE', user)

    ## Design & AIT - 760650
    user   = createUser('760650', 'aby@12345', 'Nachiyappan', 'R')
    folder = createFolder('Design & AIT', user)
    folder = createFolder('HR', user)

    ## Welding Engineering & Metallurgy - 20057679
    user   = createUser('20057679', 'aby@12345', 'Nirav', 'Kotadiya')
    folder = createFolder('Welding Engineering & Metallurgy', user)
    folder = createFolder('Production', user)

    ## PMG (Structure) - 123089
    user   = createUser('123089', 'aby@12345', 'Rajni', 'Parekh')
    folder = createFolder('PMG (Structure)', user)
    folder = createFolder('F&A', user)
