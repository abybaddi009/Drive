from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.parsers import FileUploadParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import generics

from uploadapp.models import FolderModel, FileModel
from uploadapp.serializers import FolderSerializer, FileSerializer, UserSerializer


@api_view(['GET'])
def current_user(request):
    """
    Determine the current user by their token, and return their data
    """
    serializer = UserSerializer(request.user)
    return Response(serializer.data)


class FileUploadView(APIView):
    parser_class = (FileUploadParser, )
    permission_classes = [IsAuthenticated, ]

    def post(self, request, *args, **kwargs):

        file_serializer = FileSerializer(data=request.data)

        if file_serializer.is_valid():
            found_files = FileModel.objects.filter(
                name=request.data.get('name'),
                parent_folder=request.data.get('parent_folder')
            )

            if found_files.count() > 0:
                return Response({"detail": "File Already exists in the folder."},
                                status.HTTP_400_BAD_REQUEST)

            instance = file_serializer.save(owner=request.user)
            return Response(file_serializer.data, status.HTTP_201_CREATED)
        else:
            return Response(file_serializer.errors,
                            status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated, ])
def getHomeFolderView(request):
    """
    Determine the current user by their token, and return their root_folder
    """
    user = request.user
    root_folders = FolderModel.objects.filter(
        owner=user, is_root=True)
    if root_folders.count() > 0:
        root_folder_serializer = FolderSerializer(root_folders.first())
    return Response(root_folder_serializer.data)


class FolderList(generics.ListCreateAPIView):
    serializer_class = FolderSerializer
    permission_classes = [IsAuthenticated, ]

    def get_queryset(self):
        user = self.request.user
        root_folders = FolderModel.objects.filter(
            owner=user, is_root=True)
        if root_folders.count() > 0:
            root_folder_instance = root_folders.first()
            return FolderModel.objects.filter(parent_folder=root_folder_instance)
        return None


class FolderDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = FolderModel.objects.all()
    serializer_class = FolderSerializer
    permission_classes = [IsAuthenticated, ]
