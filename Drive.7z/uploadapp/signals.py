import os
from django.conf import settings

from . import models


def create_folder(sender, instance, created, **kwargs):
    if created:
        if instance.parent_folder is not None:
            parent_folder_location = instance.parent_folder.location
            folder_location = os.path.join(parent_folder_location,
                                           str(instance.id))
            print('Folder Location for {} is {}'.format(instance.name,
                                                        folder_location))
            if not os.path.exists(folder_location):
                instance.location = folder_location
                instance.save()
                print('Instance.location = {}'.format(instance.location))
                os.mkdir(folder_location)


def create_user(sender, instance, created, **kwargs):
    if created:
        root_folder_name = "root_" + instance.username
        user_folder = os.path.join(
            settings.FILE_PATH_FIELD_DIRECTORY, root_folder_name)
        root_folder = models.FolderModel.objects.create(
            name=root_folder_name, owner=instance, location=user_folder, is_root=True)
        print('Root.location = {}'.format(root_folder.location))
        if not os.path.exists(user_folder):
            os.mkdir(user_folder)
