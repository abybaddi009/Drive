from django.contrib import admin

from .models import FileModel, FolderModel
# Register your models here.


admin.site.register(FileModel)
admin.site.register(FolderModel)
