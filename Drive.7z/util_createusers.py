from django.contrib.auth.models import User

from uploadapp.models import FolderModel


def createUser(name, password, firstname, lastname):
    user = User.objects.create_user(name, password=password)
    user.first_name = firstname
    user.last_name = lastname
    user.is_staff = True
    user.save()
    root_folder = FolderModel.objects.filter(
        is_root=True, owner=user).first()
    return (user, root_folder)


def createFolder(folder_name, user, root_folder=None):
    if root_folder is None:
        root_folder = FolderModel.objects.filter(
            is_root=True, owner=user).first()

    folder = FolderModel.objects.create(name=folder_name,
                                        owner=user,
                                        parent_folder=root_folder,
                                        published=True)
    return folder


def create_users():
    ## QC - 122784
    user, root_folder = createUser('122784', 'aby@12345', 'Munjal', 'Patel')
    folder = createFolder('Quality Control', user, root_folder=root_folder)
    folder = createFolder('Quality Assurance & Laboratory',
                          user, root_folder=root_folder)
    folder = createFolder('TQM', user, root_folder=root_folder)
    folder = createFolder('NDE', user, root_folder=root_folder)

    ## Design & AIT - 760650
    user, root_folder = createUser('760650', 'aby@12345', 'Nachiyappan', 'R')
    folder = createFolder('Design & AIT', user, root_folder=root_folder)
    folder = createFolder('HR', user, root_folder=root_folder)

    # Welding Engineering & Metallurgy - 20057679
    user, root_folder = createUser(
        '20057679', 'aby@12345', 'Nirav', 'Kotadiya')
    folder = createFolder(
        'Welding Engineering & Metallurgy', user, root_folder=root_folder)
    folder = createFolder('Production', user, root_folder=root_folder)

    ## PMG (Structure) - 123089
    user, root_folder = createUser('123089', 'aby@12345', 'Rajni', 'Parekh')
    folder = createFolder('PMG (Structure)', user, root_folder=root_folder)
    folder = createFolder('F&A', user, root_folder=root_folder)


if __name__ == '__main__':
    create_users()
